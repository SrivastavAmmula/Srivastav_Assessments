﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace test1
{
    internal class Q1
    {
        static void Main()
        {
            double p = 1000.00;
            double rate = 0.05;
            double t = 100000.00;
            int years = 0;
            while (p < t)
            {
                p += p * rate;
                years++;
            }
            Console.WriteLine($"It will take {years} year to get more than Rs 100,000.");
        }
    }
}