﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace test1
{
    class Car
    {
        public string Model { get; set; }
        public int YearOfMaking { get; set; }

        public Car(string model, int yearOfMaking)
        {
            Model = model;
            YearOfMaking = yearOfMaking;
        }

        public override string ToString()
        {
            return $"Model: {Model}, Year of Making: {YearOfMaking}";
        }
    }

    class Q3
    {
        static void Main()
        {
            Console.Write("Enter the car model: ");
            string model = Console.ReadLine();

            Console.Write("Enter the year of making: ");
            int yearOfMaking;
            while (!int.TryParse(Console.ReadLine(), out yearOfMaking) || yearOfMaking <= 0)
            {
                Console.Write("Please enter a valid year: ");
            }

            Car car = new Car(model, yearOfMaking);

            string filePath = "D:/CarDetails.txt";

            try
            {
                using (StreamWriter writer = new StreamWriter(filePath, true))
                {
                    writer.WriteLine(car.ToString());
                }
                Console.WriteLine("Car details saved successfully.");
            }
            catch (Exception ex)
            {
                Console.WriteLine("An error occurred while saving car details: " + ex.Message);
            }
        }
    }
}
